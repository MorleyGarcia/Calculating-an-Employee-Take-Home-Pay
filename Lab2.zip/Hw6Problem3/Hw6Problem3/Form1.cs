﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Hw6Problem3
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Name_TextChanged(object sender, EventArgs e)
        {

        }

        private void totalSales_TextChanged(object sender, EventArgs e)
        {

        }

        private void btnCalc_Click(object sender, EventArgs e)
        {
            string n = Nemp.Text; //employee name
            double t = GetInput(totalSales.Text,0); //Weekly Sale

            double commissions = Deductions(t,.07); //7% 
            double tax = Deductions(commissions, .18);//18%
            double retirement = Deductions(commissions, .15);//15%
            double social = Deductions(commissions, .09);//9%
            double totalD = tax + retirement + social;
            double net = calcNetPay(commissions, totalD);

            fedTax.Text = tax.ToString("F");
            RetCon.Text = retirement.ToString("F");
            SS.Text = social.ToString("F");
            label9.Text = net.ToString("F");

        
        }

        private double Deductions(double var, double pd)
        {
            double total = var * pd;

            return total;
        }

        private double calcNetPay(double total, double deductions)
        {
            double net = total - deductions;
            return net;
        }
        private double GetInput(string s, double low)
        {

            double z = 0;
            if (double.TryParse(s, out z))
            {
                double test = Convert.ToDouble(s);
                if (test >= low)
                {
                    
                        return test;
                 
                }
                else
                {
                    MessageBox.Show("Total Weekly sales must be a positive number.");
                    totalSales.Clear();
                    return 0;

                }
            }
            else
            {
                MessageBox.Show("You did not input valid numbers please try again.");
                totalSales.Clear();
                return 0;
            }
        }

        private void fedTax_TextChanged(object sender, EventArgs e)
        {

        }
    

        private void RetCon_TextChanged(object sender, EventArgs e)
        {

        }

        private void SS_TextChanged(object sender, EventArgs e)
        {

        }

        private void btnClr_Click(object sender, EventArgs e)
        {
            Nemp.Text = "";
            totalSales.Text = "";
            fedTax.Text = "";
            SS.Text = "";
            RetCon.Text = "";
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void label9_Click(object sender, EventArgs e)
        {

        }
    }
}
